Номер билда Thermos: 1614.57

Изменения:
1) Удалён оригинальный authlib из minecraft_server.1.7.10.jar (com.mojang.authlib.*)
2) Заменён LaunchWrapper 1.12 с фиксом загрузки лаунчера и Authlib
3) Добавлен Launcher.jar и LauncherAuthlib.jar в classpath
4) Обновлён ASM с 5.0.3 до 5.1
5) Обновлён JAnsi с 1.8 до 1.11
6) Обновлён JLine2 с 2.6 до 2.12.1
7) Добавлен мод NEI

(c) sashok724
